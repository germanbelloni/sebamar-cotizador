import type { Cliente } from "../types";

interface ClienteFormProps {
  cliente: Cliente;
  setCliente: React.Dispatch<React.SetStateAction<Cliente>>;
}

export function ClienteForm({ cliente, setCliente }: ClienteFormProps) {
  const handleChange =
    (field: keyof Cliente) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setCliente((prev) => ({
        ...prev,
        [field]: e.target.value,
      }));
    };

  return (
    <div className="space-y-3 rounded-xl border bg-white p-4">
      <h2 className="text-sm font-semibold text-zinc-700">Cliente</h2>

      <input
        type="text"
        placeholder="Nombre"
        value={cliente.nombre}
        onChange={handleChange("nombre")}
        className="w-full rounded-md border px-3 py-2 text-sm"
      />

      <input
        type="text"
        inputMode="tel"
        placeholder="Teléfono"
        value={cliente.telefono}
        onChange={handleChange("telefono")}
        className="w-full rounded-md border px-3 py-2 text-sm"
      />

      <input
        type="text"
        placeholder="Dirección / Obra"
        value={cliente.direccion || ""}
        onChange={handleChange("direccion")}
        className="w-full rounded-md border px-3 py-2 text-sm"
      />

      <textarea
        placeholder="Observaciones"
        value={cliente.observaciones || ""}
        onChange={handleChange("observaciones")}
        className="min-h-[80px] w-full rounded-md border px-3 py-2 text-sm"
      />
    </div>
  );
}
